import 'package:flutter/material.dart';
import '../../../widgets/title.dart';
import '../../../widgets/input-password.dart';
import '../../../widgets/input.dart';
import '../../../widgets/btn-rouge.dart';
import 'package:firebase_auth/firebase_auth.dart';

class ConnexionView extends StatefulWidget {
  const ConnexionView({super.key});

  @override
  _ConnexionViewState createState() => _ConnexionViewState();
}

class _ConnexionViewState extends State<ConnexionView> {
  //final _formKey = GlobalKey<FormState>();
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();
  final _auth = FirebaseAuth.instance;
  bool _isLoading = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              CustomTitle(
                text: "Connexion",
              ),
              const SizedBox(height: 16),
              InscriptionInput(
                controller: _emailController,
                label: "E-mail",
                hintText: "Entrez votre e-mail",
              ),
              PasswordInput(
                controller: _passwordController,
                label: "Mot de passe",
                hintText: "Entrez votre mot de passe",
              ),
              const SizedBox(height: 16),
              RedButton(
                text: "Se connecter",
                onPressed: _handleLogin,
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _handleLogin() async {
    if (_isLoading) return;

    setState(() {
      _isLoading = true;
    });

    try {
      await _auth.signInWithEmailAndPassword(
        email: _emailController.text.trim(),
        password: _passwordController.text,
      );

      if (mounted) {
        // Redirection vers la page d'accueil
        Navigator.pushReplacementNamed(context, '/home');
        // Ou si vous préférez utiliser pushNamed :
        // Navigator.pushNamed(context, '/home');
      }
    } on FirebaseAuthException catch (e) {
      String message = 'Une erreur est survenue';

      switch (e.code) {
        case 'invalid-email':
          message = 'Email invalide';
          break;
        case 'user-not-found':
          message = 'Aucun utilisateur trouvé avec cet email';
          break;
        case 'wrong-password':
          message = 'Mot de passe incorrect';
          break;
      }

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(message)),
        );
      }
    } finally {
      if (mounted) {
        setState(() {
          _isLoading = false;
        });
      }
    }
  }
}
